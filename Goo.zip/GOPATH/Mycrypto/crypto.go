package Mycrypto

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"fmt"
)

func producekey() (*rsa.PrivateKey, rsa.PublicKey, error) {
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		panic(err)
	}
	publicKey := privateKey.PublicKey

	return privateKey, publicKey, nil
}

func encode(publicKey *rsa.PublicKey, data []byte) ([]byte, error) {
	//	编码
	encryptedBytes, err := rsa.EncryptOAEP(
		sha256.New(),
		rand.Reader,
		publicKey,
		data,
		nil)
	if err != nil {
		panic(err)
	}

	fmt.Println("encrypted bytes: ", encryptedBytes)

	return encryptedBytes, nil
}

func decode(privateKey *rsa.PrivateKey, encryptedBytes []byte) ([]byte, error) {
	//	解码
	decryptedBytes, err := privateKey.Decrypt(
		nil,
		encryptedBytes,
		&rsa.OAEPOptions{Hash: crypto.SHA256})

	if err != nil {
		panic(err)
	}

	return decryptedBytes, nil
}
