package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"fmt"
	_ "net/http/pprof" // 引入 pprof 包
	"sync"
	"time"
)

// 生成随机字节
func generateRandomBytes(size int) ([]byte, error) {
	bytes := make([]byte, size)
	_, err := rand.Read(bytes)
	if err != nil {
		return nil, err
	}
	return bytes, nil
}

// 生成密钥对
func producekey() (*rsa.PrivateKey, rsa.PublicKey, error) {
	privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		panic(err)
	}
	publicKey := privateKey.PublicKey

	return privateKey, publicKey, nil
}

func main() {

	PrivateKey, PublicKey, err := producekey()
	if err != nil {
		panic(err)
	}

	startTime := time.Now()

	var wg sync.WaitGroup
	var MU = sync.Mutex{}
	numIterations := 100000
	numWorkers := 16
	i := 0

	jobs := make(chan []byte, numIterations)

	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			for encryptedBytes := range jobs {
				//	解码
				_, err := PrivateKey.Decrypt(
					nil,
					encryptedBytes,
					&rsa.OAEPOptions{Hash: crypto.SHA256})

				if err != nil {
					panic(err)
				}
				MU.Lock()
				i++
				MU.Unlock()

			}

		}()
	}

	for i := 0; i < numIterations; i++ {
		data, err := generateRandomBytes(64)
		if err != nil {
			fmt.Println("生成数据错误:", err)
			return
		}

		encryptedBytes, err := rsa.EncryptOAEP(
			sha256.New(),
			rand.Reader,
			&PublicKey,
			data,
			nil)
		if err != nil {
			panic(err)
		}

		jobs <- encryptedBytes
	}

	close(jobs)
	wg.Wait()
	endTime := time.Now()
	duration := endTime.Sub(startTime)

	fmt.Printf("使用核心数: %v\n", numWorkers)
	fmt.Printf("耗时: %v\n", duration)
	fmt.Printf("实际加密解密次数:%v", i)
}
