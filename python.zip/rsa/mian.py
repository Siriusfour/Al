
import time

import concurrent.futures
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes

# 生成随机字节
def generate_random_bytes(size):
    return get_random_bytes(size)

# 生成密钥对
def produce_key():
    key = RSA.generate(2048)
    return key, key.publickey()

# 解密函数
def decrypt(encrypted_bytes, private_key):
    cipher = PKCS1_OAEP.new(private_key, hashAlgo=SHA256)
    return cipher.decrypt(encrypted_bytes)

def worker(jobs, private_key, results):
    for encrypted_bytes in jobs:
        try:
            decrypt(encrypted_bytes, private_key)
            results.append(1)  # 计数成功解密
        except Exception as e:
            print(f"解密错误: {e}")

def main():
    private_key, public_key = produce_key()

    start_time = time.time()

    num_iterations = 100000
    num_workers = 16  # 可以根据需要调整工作线程数
    results = []

    jobs = []
    for _ in range(num_iterations):
        data = generate_random_bytes(64)
        cipher = PKCS1_OAEP.new(public_key, hashAlgo=SHA256)
        encrypted_bytes = cipher.encrypt(data)
        jobs.append(encrypted_bytes)

    # 使用线程池执行并发解密
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as executor:
        futures = []
        chunk_size = len(jobs) // num_workers
        for i in range(num_workers):
            chunk = jobs[i * chunk_size:(i + 1) * chunk_size] if i < num_workers - 1 else jobs[i * chunk_size:]
            futures.append(executor.submit(worker, chunk, private_key, results))

        # 等待所有工作完成
        concurrent.futures.wait(futures)

    end_time = time.time()
    duration = end_time - start_time

    print(f"使用核心数: {num_workers}")
    print(f"耗时: {duration:.2f}秒")
    print(f"实际加密解密次数: {len(results)}")

if __name__ == "__main__":
    main()
